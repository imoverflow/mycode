#include <iostream>
#include <stdio.h>
#include <queue>
#include <algorithm>
#include <string.h>

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
